<?php if(!empty (\Session::get('messageError'))): ?>
<script type="text/javascript">

 swal("<?php echo e(\Session::get('messageError')); ?>")

</script>

<?php endif; ?>
<?php if(!empty (\Session::get('insertError'))): ?>
<script type="text/javascript">

 swal("<?php echo e(\Session::get('insertError')); ?>",'Isi Semua Data!','error')

</script>

<?php endif; ?>
<?php if(!empty (\Session::get('insertSuccess'))): ?>
<script type="text/javascript">

 swal("<?php echo e(\Session::get('insertSuccess')); ?>", "You clicked the button!", "success")

</script>

<?php endif; ?>
<?php if(!empty (\Session::get('DeleteFails'))): ?>
<script type="text/javascript">

 swal("Gagal Menghapus !!", "<?php echo e(\Session::get('DeleteFails')); ?>", "error")

</script>

<?php endif; ?>
<?php if(!empty (\Session::get('DeleteSucces'))): ?>
<script type="text/javascript">

 swal("GOOD", "<?php echo e(\Session::get('DeleteSucces')); ?>", "success")

</script>

<?php endif; ?>

<?php if(!empty(\Session::get('insertFailsInfantUndang'))): ?>
<script type="text/javascript">
 swal("Gagal Menyimpan","Nama Infant dan Nama pejabat yang di undang sama !",'error')
</script>
<?php endif; ?>
<?php if(!empty(\Session::get('insertFailsdate'))): ?>
<script type="text/javascript">
 swal("Gagal Menyimpan","waktu mulai lebih besar dari waktu akhir !",'error')
</script>
<?php endif; ?>
<?php if(!empty(\Session::get('insertFailsRuangan'))): ?>
<script type="text/javascript">
 swal("Gagal Menyimpan","Ruangan yang anda gunakan sudah terisi",'error')
</script>
<?php endif; ?>
