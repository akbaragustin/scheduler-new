@include('layouts.header')

  @yield('content')
@include('layouts.modal')
@include('layouts.footer')
